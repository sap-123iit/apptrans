package com.voxflow.keyboard;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TextCleanerTest {
    @Test
    public void removesFillerAndCapitalizes() {
        assertEquals("Send the report.", TextCleaner.clean("um send the report"));
    }

    @Test
    public void removesRepeatedPhrase() {
        assertEquals("We should launch tomorrow.", TextCleaner.clean("we should we should launch tomorrow"));
    }

    @Test
    public void convertsSpokenPunctuation() {
        assertEquals("Hello, how are you?", TextCleaner.clean("hello comma how are you question mark"));
    }

    @Test
    public void supportsParagraphs() {
        assertEquals("First point.\n\nSecond point.", TextCleaner.clean("first point full stop new paragraph second point"));
    }

    @Test
    public void addsLeadingSpaceWhenNeeded() {
        assertEquals(" Hello.", TextCleaner.prepareForInsertion("hello", true, true));
    }

    @Test
    public void ignoresAccessibilityHintPresentedAsText() {
        assertEquals("", TextCleaner.editableValue("Message", "Message", true, 0, 0));
        assertEquals("", TextCleaner.editableValue("Message", "Message", false, 0, 0));
    }

    @Test
    public void preservesTypedTextThatMatchesTheHint() {
        assertEquals("Message", TextCleaner.editableValue("Message", "Message", false, 7, 7));
    }
}

