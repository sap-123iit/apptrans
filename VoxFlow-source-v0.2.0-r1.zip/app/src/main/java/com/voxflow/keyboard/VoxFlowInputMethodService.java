package com.voxflow.keyboard;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class VoxFlowInputMethodService extends InputMethodService implements RecognitionListener, WhisperEngine.Listener {
    private static final long RESTART_DELAY_MS = 280L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private WhisperEngine whisperEngine;
    private boolean usingWhisper;
    private boolean wantsContinuousListening;
    private boolean recognitionInProgress;
    private boolean leadingSpaceNeeded;
    private int lastCommittedLength;

    private TextView brand;
    private TextView preview;
    private Button micButton;
    private Button languageButton;
    private Button modeButton;

    @Override
    public View onCreateInputView() {
        View view = getLayoutInflater().inflate(R.layout.keyboard_voice, null);
        brand = view.findViewById(R.id.keyboardBrand);
        preview = view.findViewById(R.id.previewText);
        micButton = view.findViewById(R.id.micButton);
        languageButton = view.findViewById(R.id.languageButton);
        modeButton = view.findViewById(R.id.modeButton);

        micButton.setOnClickListener(ignored -> toggleListening());
        languageButton.setOnClickListener(ignored -> cycleLanguage());
        modeButton.setOnClickListener(ignored -> toggleCleanMode());
        view.findViewById(R.id.backspaceButton).setOnClickListener(ignored -> backspace());
        view.findViewById(R.id.enterButton).setOnClickListener(ignored -> sendEnter());
        view.findViewById(R.id.undoButton).setOnClickListener(ignored -> undoLastPhrase());
        view.findViewById(R.id.settingsButton).setOnClickListener(ignored -> openSettings());

        updatePreferenceLabels();
        renderIdle();
        if (whisperEngine == null) whisperEngine = new WhisperEngine(getApplicationContext(), this);
        return view;
    }

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        updatePreferenceLabels();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        stopContinuousListening(false);
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onDestroy() {
        stopContinuousListening(true);
        destroyRecognizer();
        if (whisperEngine != null) whisperEngine.close();
        super.onDestroy();
    }

    private void toggleListening() {
        if (wantsContinuousListening) {
            stopContinuousListening(false);
        } else {
            startContinuousListening();
        }
    }

    private void startContinuousListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            preview.setText("Open VoxFlow settings and allow microphone access first.");
            openSettings();
            return;
        }
        wantsContinuousListening = true;
        lastCommittedLength = 0;

        if (VoxFlowPreferences.offlinePreferred(this)) {
            usingWhisper = true;
            renderListening("Loading offline AI…");
            preview.setText("The Whisper model takes a moment to load the first time.");
            whisperEngine.start(
                    VoxFlowPreferences.whisperLanguage(this),
                    VoxFlowPreferences.vocabulary(this)
            );
            return;
        }

        usingWhisper = false;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            preview.setText("No Android speech service is installed on this phone.");
            brand.setText("VoxFlow · Speech service unavailable");
            wantsContinuousListening = false;
            return;
        }
        createRecognizer();
        beginRecognitionSession();
    }

    private void stopContinuousListening(boolean cancel) {
        wantsContinuousListening = false;
        handler.removeCallbacksAndMessages(null);
        if (usingWhisper && whisperEngine != null) {
            whisperEngine.stop();
            usingWhisper = false;
        }
        if (recognizer != null && recognitionInProgress) {
            if (cancel) recognizer.cancel();
            else recognizer.stopListening();
        }
        recognitionInProgress = false;
        if (micButton != null) renderIdle();
    }

    private void createRecognizer() {
        destroyRecognizer();
        boolean preferOnDevice = VoxFlowPreferences.offlinePreferred(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && preferOnDevice
                && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
        } else {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        }
        recognizer.setRecognitionListener(this);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
    }

    private void beginRecognitionSession() {
        if (!wantsContinuousListening || recognitionInProgress || recognizer == null) return;
        InputConnection connection = getCurrentInputConnection();
        CharSequence before = connection == null ? null : connection.getTextBeforeCursor(1, 0);
        leadingSpaceNeeded = before != null && before.length() > 0
                && !Character.isWhitespace(before.charAt(0))
                && ".,;:!?([{/\n".indexOf(before.charAt(0)) < 0;

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, VoxFlowPreferences.languageTag(this));
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, VoxFlowPreferences.offlinePreferred(this));
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 650L);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING, RecognizerIntent.FORMATTING_OPTIMIZE_LATENCY);
            intent.putExtra(RecognizerIntent.EXTRA_HIDE_PARTIAL_TRAILING_PUNCTUATION, true);
            ArrayList<String> vocabulary = customVocabulary();
            if (!vocabulary.isEmpty()) intent.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, vocabulary);
        }

        recognitionInProgress = true;
        recognizer.startListening(intent);
        renderListening("Starting…");
    }

    private ArrayList<String> customVocabulary() {
        String saved = VoxFlowPreferences.vocabulary(this);
        ArrayList<String> words = new ArrayList<>();
        if (saved.isEmpty()) return words;
        for (String candidate : saved.split(",")) {
            String value = candidate.trim();
            if (!value.isEmpty()) words.add(value);
            if (words.size() == 50) break;
        }
        return words;
    }

    private void cycleLanguage() {
        int current = VoxFlowPreferences.languageIndex(this);
        int next = (current + 1) % VoxFlowPreferences.LANGUAGE_TAGS.length;
        VoxFlowPreferences.save(
                this,
                next,
                VoxFlowPreferences.cleanEnabled(this),
                VoxFlowPreferences.offlinePreferred(this),
                VoxFlowPreferences.vocabulary(this)
        );
        updatePreferenceLabels();
        if (wantsContinuousListening) {
            stopContinuousListening(true);
            handler.postDelayed(this::startContinuousListening, RESTART_DELAY_MS);
        }
    }

    private void toggleCleanMode() {
        VoxFlowPreferences.save(
                this,
                VoxFlowPreferences.languageIndex(this),
                !VoxFlowPreferences.cleanEnabled(this),
                VoxFlowPreferences.offlinePreferred(this),
                VoxFlowPreferences.vocabulary(this)
        );
        updatePreferenceLabels();
    }

    private void updatePreferenceLabels() {
        if (languageButton == null) return;
        languageButton.setText(VoxFlowPreferences.LANGUAGE_LABELS[VoxFlowPreferences.languageIndex(this)]);
        modeButton.setText(VoxFlowPreferences.cleanEnabled(this) ? "✨ Clean" : "Verbatim");
    }

    private void backspace() {
        InputConnection connection = getCurrentInputConnection();
        if (connection != null) connection.deleteSurroundingText(1, 0);
        lastCommittedLength = 0;
    }

    private void sendEnter() {
        InputConnection connection = getCurrentInputConnection();
        if (connection != null) {
            connection.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
            connection.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
        }
        lastCommittedLength = 0;
    }

    private void undoLastPhrase() {
        InputConnection connection = getCurrentInputConnection();
        if (connection != null && lastCommittedLength > 0) {
            connection.deleteSurroundingText(lastCommittedLength, 0);
            preview.setText("Last dictated phrase removed.");
            lastCommittedLength = 0;
        } else if (preview != null) {
            preview.setText("Nothing recent to undo.");
        }
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void renderListening(String detail) {
        if (brand == null) return;
        brand.setText("VoxFlow · " + detail);
        micButton.setText("■  Stop dictating");
        micButton.setBackground(makeRoundedBackground(getColor(R.color.danger), 16));
    }

    private void renderIdle() {
        brand.setText("VoxFlow · Ready");
        micButton.setText("●  Start dictating");
        micButton.setBackground(makeRoundedBackground(getColor(R.color.accent), 16));
    }

    private GradientDrawable makeRoundedBackground(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        return drawable;
    }

    private void scheduleNextSession() {
        recognitionInProgress = false;
        if (wantsContinuousListening) {
            handler.postDelayed(this::beginRecognitionSession, RESTART_DELAY_MS);
        } else {
            renderIdle();
        }
    }

    private String firstResult(Bundle bundle) {
        ArrayList<String> matches = bundle == null ? null : bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return matches == null || matches.isEmpty() ? "" : matches.get(0).trim();
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        renderListening("Listening");
        preview.setText("Listening…");
    }

    @Override
    public void onBeginningOfSpeech() {
        renderListening("Hearing you");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
        if (micButton != null) micButton.setAlpha(Math.max(0.72f, Math.min(1f, 0.78f + rmsdB / 50f)));
    }

    @Override
    public void onBufferReceived(byte[] buffer) {}

    @Override
    public void onEndOfSpeech() {
        renderListening("Polishing…");
    }

    @Override
    public void onError(int error) {
        recognitionInProgress = false;
        InputConnection connection = getCurrentInputConnection();
        if (connection != null) connection.finishComposingText();

        if (!wantsContinuousListening) {
            renderIdle();
            return;
        }

        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            wantsContinuousListening = false;
            preview.setText("Microphone access is required. Open VoxFlow settings.");
            renderIdle();
            return;
        }
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
            destroyRecognizer();
            handler.postDelayed(() -> {
                if (wantsContinuousListening) {
                    createRecognizer();
                    beginRecognitionSession();
                }
            }, 700L);
            return;
        }

        if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
            preview.setText("Network recognition unavailable. Try on-device mode or install a language pack.");
        } else if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            preview.setText("Speech service paused (error " + error + "). Retrying…");
        }
        handler.postDelayed(this::beginRecognitionSession, 520L);
    }

    @Override
    public void onResults(Bundle results) {
        String raw = firstResult(results);
        InputConnection connection = getCurrentInputConnection();
        if (!raw.isEmpty() && connection != null) {
            String polished = TextCleaner.prepareForInsertion(
                    raw,
                    VoxFlowPreferences.cleanEnabled(this),
                    leadingSpaceNeeded
            );
            connection.commitText(polished, 1);
            connection.finishComposingText();
            preview.setText(polished.trim());
            lastCommittedLength = polished.length();
        }
        scheduleNextSession();
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        String raw = firstResult(partialResults);
        InputConnection connection = getCurrentInputConnection();
        if (!raw.isEmpty() && connection != null) {
            String partial = TextCleaner.prepareForInsertion(raw, false, leadingSpaceNeeded);
            connection.setComposingText(partial, 1);
            preview.setText(raw);
        }
    }

    @Override
    public void onWhisperReady() {
        handler.post(() -> {
            if (wantsContinuousListening && usingWhisper) {
                renderListening("Listening offline");
                preview.setText("Listening locally — pause briefly to insert a phrase.");
            }
        });
    }

    @Override
    public void onWhisperVoiceState(boolean speaking) {
        handler.post(() -> {
            if (wantsContinuousListening && usingWhisper) {
                renderListening(speaking ? "Hearing you" : "Listening offline");
            }
        });
    }

    @Override
    public void onWhisperTranscribing() {
        handler.post(() -> {
            if (usingWhisper) {
                renderListening("Polishing locally…");
                preview.setText("Turning that phrase into text on this phone…");
            }
        });
    }

    @Override
    public void onWhisperResult(String raw) {
        handler.post(() -> {
            InputConnection connection = getCurrentInputConnection();
            if (raw != null && !raw.trim().isEmpty() && connection != null) {
                String polished = TextCleaner.prepareForInsertion(
                        raw,
                        VoxFlowPreferences.cleanEnabled(this),
                        needsLeadingSpace(connection)
                );
                connection.commitText(polished, 1);
                connection.finishComposingText();
                preview.setText(polished.trim());
                lastCommittedLength = polished.length();
            }
            if (wantsContinuousListening && usingWhisper) renderListening("Listening offline");
            else renderIdle();
        });
    }

    @Override
    public void onWhisperError(String message) {
        handler.post(() -> {
            if (!usingWhisper) return;
            usingWhisper = false;
            if (SpeechRecognizer.isRecognitionAvailable(this) && wantsContinuousListening) {
                preview.setText("Offline AI could not start; using Android speech as fallback.");
                createRecognizer();
                beginRecognitionSession();
            } else {
                wantsContinuousListening = false;
                preview.setText(message);
                renderIdle();
            }
        });
    }

    private boolean needsLeadingSpace(InputConnection connection) {
        CharSequence before = connection.getTextBeforeCursor(1, 0);
        return before != null && before.length() > 0
                && !Character.isWhitespace(before.charAt(0))
                && ".,;:!?([{/\n".indexOf(before.charAt(0)) < 0;
    }

    @Override
    public void onEvent(int eventType, Bundle params) {}
}

