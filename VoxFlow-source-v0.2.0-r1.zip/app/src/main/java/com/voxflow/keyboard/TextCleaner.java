package com.voxflow.keyboard;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TextCleaner {
    private static final Pattern FILLERS = Pattern.compile(
            "(?iu)(^|[\\s,])(?:um+|uh+|erm+|hmm+|mm+hmm+)(?=$|[\\s,.!?])[,\\s]*"
    );
    private static final Pattern REPEATED_PHRASE = Pattern.compile(
            "(?iu)\\b([\\p{L}\\p{N}']+(?:\\s+[\\p{L}\\p{N}']+){0,3})(?:[\\s,]+\\1\\b)+"
    );
    private static final Pattern SPACE_BEFORE_PUNCTUATION = Pattern.compile("\\s+([,.;:!?])");
    private static final Pattern SPACE_AFTER_PUNCTUATION = Pattern.compile("([,;:!?])(?=[\\p{L}\\p{N}])");
    private static final Pattern MULTIPLE_SPACES = Pattern.compile("[ \\t]{2,}");
    private static final Pattern TOO_MANY_NEWLINES = Pattern.compile("\\n{3,}");

    private TextCleaner() {}

    public static String clean(String raw) {
        if (raw == null) return "";
        String text = raw.trim();
        if (text.isEmpty()) return text;

        text = replaceSpokenFormatting(text);
        text = removeFillers(text);
        for (int i = 0; i < 3; i++) {
            Matcher repetition = REPEATED_PHRASE.matcher(text);
            String reduced = repetition.replaceAll("$1");
            if (reduced.equals(text)) break;
            text = reduced;
        }

        text = SPACE_BEFORE_PUNCTUATION.matcher(text).replaceAll("$1");
        text = SPACE_AFTER_PUNCTUATION.matcher(text).replaceAll("$1 ");
        text = MULTIPLE_SPACES.matcher(text).replaceAll(" ");
        text = text.replaceAll(" *\\n *", "\n");
        text = TOO_MANY_NEWLINES.matcher(text).replaceAll("\n\n").trim();
        text = capitalizeSentences(text);

        if (!text.isEmpty() && Character.isLetterOrDigit(text.charAt(text.length() - 1))) {
            text += ".";
        }
        return text;
    }

    public static String prepareForInsertion(String raw, boolean clean, boolean leadingSpace) {
        String text = clean ? clean(raw) : normalizeVerbatim(raw);
        if (text.isEmpty()) return text;
        if (leadingSpace && !startsWithPunctuation(text)) return " " + text;
        return text;
    }

    static String editableValue(
            CharSequence value,
            CharSequence hint,
            boolean showingHint,
            int selectionStart,
            int selectionEnd) {
        if (value == null) return "";
        String text = value.toString();
        boolean placeholderMatches = hint != null && text.contentEquals(hint);
        if (showingHint || placeholderMatches && selectionStart <= 0 && selectionEnd <= 0) return "";
        return text;
    }

    private static String normalizeVerbatim(String raw) {
        if (raw == null) return "";
        return MULTIPLE_SPACES.matcher(raw.trim()).replaceAll(" ");
    }

    private static String removeFillers(String text) {
        Matcher matcher = FILLERS.matcher(text);
        StringBuffer output = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(output, Matcher.quoteReplacement(matcher.group(1)));
        }
        matcher.appendTail(output);
        return output.toString().trim();
    }

    private static String replaceSpokenFormatting(String text) {
        return text
                .replaceAll("(?iu)\\bnew paragraph\\b", "\n\n")
                .replaceAll("(?iu)\\bnew line\\b", "\n")
                .replaceAll("(?iu)\\b(?:full stop|period)\\b", ".")
                .replaceAll("(?iu)\\bquestion mark\\b", "?")
                .replaceAll("(?iu)\\bexclamation (?:mark|point)\\b", "!")
                .replaceAll("(?iu)\\bcomma\\b", ",")
                .replaceAll("(?iu)\\bcolon\\b", ":")
                .replaceAll("(?iu)\\bsemicolon\\b", ";");
    }

    private static String capitalizeSentences(String text) {
        StringBuilder result = new StringBuilder(text.length());
        boolean capitalizeNext = true;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (capitalizeNext && Character.isLetter(c)) {
                result.append(String.valueOf(c).toUpperCase(Locale.getDefault()));
                capitalizeNext = false;
            } else {
                result.append(c);
            }
            if (c == '.' || c == '!' || c == '?' || c == '\n') capitalizeNext = true;
            else if (!Character.isWhitespace(c)) capitalizeNext = false;
        }
        return result.toString();
    }

    private static boolean startsWithPunctuation(String text) {
        char first = text.charAt(0);
        return ",.;:!?)]}".indexOf(first) >= 0;
    }
}

