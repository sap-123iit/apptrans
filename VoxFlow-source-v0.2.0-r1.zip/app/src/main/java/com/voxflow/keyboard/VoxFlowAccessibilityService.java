package com.voxflow.keyboard;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.List;

public class VoxFlowAccessibilityService extends AccessibilityService implements WhisperEngine.Listener {
    private static final long REFRESH_DELAY_MS = 90L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private View floatingView;
    private ImageButton micButton;
    private WindowManager.LayoutParams floatingParams;
    private WhisperEngine whisperEngine;
    private boolean attached;
    private boolean listening;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_voice_button, null);
        micButton = floatingView.findViewById(R.id.floatingMicButton);
        micButton.setOnClickListener(view -> toggleListening());
        floatingParams = new WindowManager.LayoutParams(
                dp(56),
                dp(56),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        floatingParams.gravity = Gravity.BOTTOM | Gravity.END;
        floatingParams.x = dp(12);
        floatingParams.y = dp(96);

        whisperEngine = new WhisperEngine(getApplicationContext(), this);
        whisperEngine.warmUp();
        scheduleOverlayRefresh();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        scheduleOverlayRefresh();
    }

    @Override
    public void onInterrupt() {
        stopListening();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopListening();
        if (whisperEngine != null) whisperEngine.close();
        hideFloatingButton();
        super.onDestroy();
    }

    private void scheduleOverlayRefresh() {
        handler.removeCallbacks(this::refreshOverlay);
        handler.postDelayed(this::refreshOverlay, REFRESH_DELAY_MS);
    }

    private void refreshOverlay() {
        AccessibilityNodeInfo editor = findFocusedEditor();
        if (editor == null) {
            if (listening) stopListening();
            hideFloatingButton();
            return;
        }
        editor.recycle();
        showFloatingButton(positionAboveKeyboard());
    }

    private AccessibilityNodeInfo findFocusedEditor() {
        List<AccessibilityWindowInfo> windows = getWindows();
        for (AccessibilityWindowInfo window : windows) {
            if (window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo root = window.getRoot();
            if (root == null) continue;
            AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            root.recycle();
            if (isUsableEditor(focused)) return focused;
            if (focused != null) focused.recycle();
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        root.recycle();
        if (isUsableEditor(focused)) return focused;
        if (focused != null) focused.recycle();
        return null;
    }

    private boolean isUsableEditor(AccessibilityNodeInfo node) {
        return node != null && node.isEditable() && node.isFocused() && !node.isPassword();
    }

    private int positionAboveKeyboard() {
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        Rect bounds = new Rect();
        for (AccessibilityWindowInfo window : getWindows()) {
            if (window.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                window.getBoundsInScreen(bounds);
                if (bounds.top > 0 && bounds.top < screenHeight) {
                    return Math.max(dp(12), screenHeight - bounds.top + dp(12));
                }
            }
        }
        return dp(96);
    }

    private void showFloatingButton(int bottomOffset) {
        if (windowManager == null || floatingView == null) return;
        floatingParams.y = bottomOffset;
        if (!attached) {
            windowManager.addView(floatingView, floatingParams);
            attached = true;
        } else {
            windowManager.updateViewLayout(floatingView, floatingParams);
        }
    }

    private void hideFloatingButton() {
        if (attached && windowManager != null && floatingView != null) {
            windowManager.removeView(floatingView);
            attached = false;
        }
    }

    private void toggleListening() {
        if (listening) {
            stopListening();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, R.string.floating_mic_permission, Toast.LENGTH_LONG).show();
            Intent settings = new Intent(this, MainActivity.class);
            settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(settings);
            return;
        }
        AccessibilityNodeInfo editor = findFocusedEditor();
        if (editor == null) {
            Toast.makeText(this, R.string.floating_mic_no_field, Toast.LENGTH_SHORT).show();
            return;
        }
        editor.recycle();
        listening = true;
        renderListening();
        whisperEngine.start(
                VoxFlowPreferences.whisperLanguage(this),
                VoxFlowPreferences.vocabulary(this)
        );
    }

    private void stopListening() {
        listening = false;
        if (whisperEngine != null) whisperEngine.stop();
        renderIdle();
    }

    private void renderIdle() {
        if (micButton == null) return;
        micButton.setImageResource(R.drawable.ic_mic);
        micButton.setBackgroundResource(R.drawable.floating_mic_idle);
        micButton.setContentDescription(getString(R.string.floating_mic_idle));
        micButton.setAlpha(1f);
    }

    private void renderListening() {
        if (micButton == null) return;
        micButton.setImageResource(R.drawable.ic_stop);
        micButton.setBackgroundResource(R.drawable.floating_mic_listening);
        micButton.setContentDescription(getString(R.string.floating_mic_listening));
        micButton.setAlpha(1f);
    }

    private void renderTranscribing() {
        if (micButton == null) return;
        micButton.setContentDescription(getString(R.string.floating_mic_working));
        micButton.setAlpha(0.62f);
    }

    private void insertText(String raw) {
        if (raw == null || raw.trim().isEmpty()) return;
        AccessibilityNodeInfo editor = findFocusedEditor();
        if (editor == null) return;

        CharSequence currentValue = editor.getText();
        String current = currentValue == null ? "" : currentValue.toString();
        int start = editor.getTextSelectionStart();
        int end = editor.getTextSelectionEnd();
        if (start < 0 || start > current.length()) start = current.length();
        if (end < start || end > current.length()) end = start;

        boolean leadingSpace = start > 0
                && !Character.isWhitespace(current.charAt(start - 1))
                && ".,;:!?([{/\n".indexOf(current.charAt(start - 1)) < 0;
        String text = TextCleaner.prepareForInsertion(
                raw,
                VoxFlowPreferences.cleanEnabled(this),
                leadingSpace
        );
        String updated = current.substring(0, start) + text + current.substring(end);

        Bundle setText = new Bundle();
        setText.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updated);
        boolean inserted = editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setText);
        if (inserted) {
            Bundle selection = new Bundle();
            int cursor = start + text.length();
            selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor);
            selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor);
            editor.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selection);
        } else {
            Toast.makeText(this, R.string.floating_mic_insert_failed, Toast.LENGTH_SHORT).show();
        }
        editor.recycle();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onWhisperReady() {
        handler.post(() -> {
            if (listening) renderListening();
        });
    }

    @Override
    public void onWhisperVoiceState(boolean speaking) {
        handler.post(() -> {
            if (listening && speaking) micButton.setAlpha(0.82f);
            else if (listening) micButton.setAlpha(1f);
        });
    }

    @Override
    public void onWhisperTranscribing() {
        handler.post(() -> {
            if (listening) renderTranscribing();
        });
    }

    @Override
    public void onWhisperResult(String text) {
        handler.post(() -> {
            insertText(text);
            if (listening) renderListening();
        });
    }

    @Override
    public void onWhisperError(String message) {
        handler.post(() -> {
            stopListening();
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }
}
