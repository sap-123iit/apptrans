#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <string>

#include "whisper.h"

#define LOG_TAG "VoxFlowWhisper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

size_t asset_read(void * context, void * output, size_t requested) {
    int read = AAsset_read(static_cast<AAsset *>(context), output, requested);
    return read < 0 ? 0 : static_cast<size_t>(read);
}

bool asset_eof(void * context) {
    return AAsset_getRemainingLength64(static_cast<AAsset *>(context)) <= 0;
}

void asset_close(void * context) {
    AAsset_close(static_cast<AAsset *>(context));
}

std::string jstring_to_utf8(JNIEnv * env, jstring value) {
    if (value == nullptr) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string result(chars == nullptr ? "" : chars);
    if (chars != nullptr) env->ReleaseStringUTFChars(value, chars);
    return result;
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_voxflow_keyboard_WhisperNative_initContextFromAsset(
        JNIEnv * env,
        jclass,
        jobject asset_manager,
        jstring asset_path) {
    std::string path = jstring_to_utf8(env, asset_path);
    AAssetManager * manager = AAssetManager_fromJava(env, asset_manager);
    if (manager == nullptr) return 0;

    AAsset * asset = AAssetManager_open(manager, path.c_str(), AASSET_MODE_STREAMING);
    if (asset == nullptr) {
        LOGE("Could not open model asset: %s", path.c_str());
        return 0;
    }

    whisper_model_loader loader = {};
    loader.context = asset;
    loader.read = asset_read;
    loader.eof = asset_eof;
    loader.close = asset_close;
    whisper_context_params parameters = whisper_context_default_params();
    whisper_context * context = whisper_init_with_params(&loader, parameters);
    return reinterpret_cast<jlong>(context);
}

extern "C" JNIEXPORT void JNICALL
Java_com_voxflow_keyboard_WhisperNative_freeContext(JNIEnv *, jclass, jlong pointer) {
    auto * context = reinterpret_cast<whisper_context *>(pointer);
    if (context != nullptr) whisper_free(context);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_voxflow_keyboard_WhisperNative_transcribe(
        JNIEnv * env,
        jclass,
        jlong pointer,
        jint thread_count,
        jfloatArray audio,
        jstring language_value,
        jstring prompt_value) {
    auto * context = reinterpret_cast<whisper_context *>(pointer);
    if (context == nullptr || audio == nullptr) return env->NewStringUTF("");

    std::string language = jstring_to_utf8(env, language_value);
    std::string prompt = jstring_to_utf8(env, prompt_value);
    jsize sample_count = env->GetArrayLength(audio);
    jfloat * samples = env->GetFloatArrayElements(audio, nullptr);
    if (samples == nullptr) return env->NewStringUTF("");

    whisper_full_params parameters = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    parameters.n_threads = thread_count;
    parameters.translate = false;
    parameters.language = language.empty() ? "auto" : language.c_str();
    parameters.initial_prompt = prompt.empty() ? nullptr : prompt.c_str();
    parameters.no_context = true;
    parameters.no_timestamps = true;
    parameters.single_segment = false;
    parameters.print_realtime = false;
    parameters.print_progress = false;
    parameters.print_timestamps = false;
    parameters.print_special = false;
    parameters.suppress_blank = true;
    parameters.suppress_nst = true;

    int status = whisper_full(context, parameters, samples, sample_count);
    env->ReleaseFloatArrayElements(audio, samples, JNI_ABORT);
    if (status != 0) {
        LOGE("whisper_full failed with code %d", status);
        return env->NewStringUTF("");
    }

    std::string transcript;
    int segments = whisper_full_n_segments(context);
    for (int index = 0; index < segments; index++) {
        const char * text = whisper_full_get_segment_text(context, index);
        if (text != nullptr) transcript.append(text);
    }
    return env->NewStringUTF(transcript.c_str());
}

