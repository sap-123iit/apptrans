# VoxFlow Floating Voice Typing

VoxFlow is an Android-first, unlimited voice-typing companion inspired by the useful part of Wispr Flow: speak naturally and put readable text into any app. Gboard remains your normal keyboard; VoxFlow adds a small floating microphone above it. The app runs the open Whisper speech model on your phone and does not use an account, API key, paid service, or word quota.

## What this first version does

- Works beside Gboard in messages, email, notes, browsers, and other editable text fields.
- Shows a subtle floating mic when a text field is active; tap once to dictate and again to stop.
- Records each natural phrase, coalesces queued speech into efficient long-form batches, transcribes it locally with multilingual Whisper `base`, and inserts the result into the active text field.
- Continues listening across natural pauses until you tap Stop.
- Includes the model inside the APK, so offline AI needs no account, network, or later download.
- Falls back to the phone's installed speech service if the local model cannot run.
- Offers Clean and Verbatim modes. Clean removes conservative filler words and repetitions, converts spoken punctuation, and fixes capitalization/spacing.
- Supports quick language switching and optional vocabulary hints for uncommon names and terms on Android 13+.
- Stores preferences only. VoxFlow itself does not save audio or transcripts.

## Accuracy and privacy reality

VoxFlow has no paid cloud AI backend. The default engine is the multilingual Whisper `base` model running through `whisper.cpp`; the official project recommends tiny or base models for Android. The model is roughly 142 MiB before APK packaging, and first load/inference speed depends on the phone's CPU. If you turn off **Use offline Whisper AI**, VoxFlow uses Android's speech service instead; that fallback may use its provider's network and privacy policy.

The model is preloaded when the floating-button service starts, the silence wait is tuned to 480 ms, and inference uses up to four CPU workers to avoid contention on mobile efficiency cores. Speech that arrives while Whisper is busy is combined into a larger follow-up batch instead of creating a slow backlog of tiny jobs. These changes reduce delay without using a smaller model or lowering transcription quality. The local Clean mode is deliberately conservative. It can remove fillers and repetitions, but it cannot yet infer complex mid-sentence corrections as deeply as Wispr Flow's cloud rewrite layer.

The floating microphone is draggable and remembers its position. Its default location is shifted away from the far-right send-button area. Tap it to start or stop; drag it to place it somewhere more convenient.

## Build the installable APK with GitHub Actions

1. Create an empty GitHub repository and upload/push this project to its `main` branch.
2. Open the repository's **Actions** tab.
3. Open **Build Android APK** and choose **Run workflow** if it did not start automatically.
4. Open the completed run and download the **voxflow-debug-apk** artifact.
5. Extract the ZIP on your phone or computer. Install `app-debug.apk` from inside it.

The workflow downloads and verifies the official multilingual model, checks out pinned `whisper.cpp` v1.9.4 source, runs unit tests, compiles the native runtime, and builds with Java 17, Android Gradle Plugin 8.5.2, Gradle 8.8, compile/target SDK 35, NDK 25.2, and CMake 3.22.1.

## Set up on the phone

1. Open VoxFlow and allow microphone access.
2. Tap **Open settings**, choose **VoxFlow floating voice button**, and allow the accessibility service.
3. Keep Gboard selected as your normal keyboard.
4. Tap any editable text field. When Gboard opens, tap the floating green VoxFlow mic to dictate; tap the red stop button to finish.

Android shows a standard warning when enabling an accessibility service. VoxFlow uses this service only to detect the focused editable field, show its mic, and insert the transcription at the current cursor. Password fields are excluded. VoxFlow declares only microphone access and includes no app-level internet permission.

## Updating a test install

Debug APKs produced on different GitHub runners may use different signing keys. If Android says an update is incompatible, uninstall the previous VoxFlow test build, then install the new APK. A production release should use one persistent release signing key stored in GitHub Secrets; never commit that key.

## Project structure

- `app/src/main/java/.../VoxFlowAccessibilityService.java` — floating mic and insertion into the focused field
- `app/src/main/java/.../VoxFlowInputMethodService.java` — legacy full-keyboard mode retained for compatibility
- `app/src/main/java/.../WhisperEngine.java` — microphone capture, voice activity detection, and local inference queue
- `app/src/main/cpp/whisper_jni.cpp` — native bridge to pinned `whisper.cpp`
- `app/src/main/java/.../TextCleaner.java` — local text cleanup
- `app/src/main/java/.../MainActivity.java` — guided setup, test editor, and preferences
- `.github/workflows/build-apk.yml` — reproducible APK build

## Next quality upgrades

The highest-impact next step is timing short and long phrases on the exact target phone. A larger model can improve recognition but substantially increases APK size, RAM use, heat, and response time. A small on-device rewrite model would be a separate later upgrade for deeper semantic corrections.

## Open-source components

- [`whisper.cpp`](https://github.com/ggml-org/whisper.cpp), pinned to v1.9.4 at build time (MIT license).
- Multilingual `ggml-base.bin` from the official [`ggerganov/whisper.cpp`](https://huggingface.co/ggerganov/whisper.cpp) model repository, verified against the SHA-1 published by the project.
