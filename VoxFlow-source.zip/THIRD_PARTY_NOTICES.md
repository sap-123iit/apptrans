# Third-party notices

## whisper.cpp

VoxFlow builds against `ggml-org/whisper.cpp` v1.9.4.

Copyright (c) 2023-2026 The ggml authors

Licensed under the MIT License. The complete license is included in the pinned upstream source fetched by the build workflow: `third_party/whisper.cpp/LICENSE`.

Project: https://github.com/ggml-org/whisper.cpp

## Whisper model

The build downloads `ggml-base.bin` from the official whisper.cpp model repository and verifies the checksum published by the whisper.cpp project.

Model repository: https://huggingface.co/ggerganov/whisper.cpp

Upstream Whisper project: https://github.com/openai/whisper
