# VoxFlow Voice Keyboard

VoxFlow is an Android-first, unlimited voice keyboard inspired by the useful part of Wispr Flow: speak naturally and put readable text into any app. It runs the open Whisper speech model on your phone. It does not use a VoxFlow account, API key, paid service, or word quota.

## What this first version does

- Works as an Android keyboard in messages, email, notes, browsers, and other text fields.
- Records each natural phrase, transcribes it locally with multilingual Whisper `base`, and inserts the result into the active text field.
- Continues listening across natural pauses until you tap Stop.
- Includes the model inside the APK, so offline AI needs no account, network, or later download.
- Falls back to the phone's installed speech service if the local model cannot run.
- Offers Clean and Verbatim modes. Clean removes conservative filler words and repetitions, converts spoken punctuation, and fixes capitalization/spacing.
- Supports quick language switching and optional vocabulary hints for uncommon names and terms on Android 13+.
- Stores preferences only. VoxFlow itself does not save audio or transcripts.

## Accuracy and privacy reality

VoxFlow has no paid cloud AI backend. The default engine is the multilingual Whisper `base` model running through `whisper.cpp`; the official project recommends tiny or base models for Android. The model is roughly 142 MiB before APK packaging, and first load/inference speed depends on the phone's CPU. If you turn off **Use offline Whisper AI**, VoxFlow uses Android's speech service instead; that fallback may use its provider's network and privacy policy.

The local Clean mode is deliberately conservative. It can remove fillers and repetitions, but it cannot yet infer complex mid-sentence corrections as deeply as Wispr Flow's cloud rewrite layer.

## Build the installable APK with GitHub Actions

1. Create an empty GitHub repository and upload/push this project to its `main` branch.
2. Open the repository's **Actions** tab.
3. Open **Build Android APK** and choose **Run workflow** if it did not start automatically.
4. Open the completed run and download the **voxflow-debug-apk** artifact.
5. Extract the ZIP on your phone or computer. Install `app-debug.apk` from inside it.

The workflow downloads and verifies the official multilingual model, checks out pinned `whisper.cpp` v1.9.4 source, runs unit tests, compiles the native runtime, and builds with Java 17, Android Gradle Plugin 8.5.2, Gradle 8.8, compile/target SDK 35, NDK 25.2, and CMake 3.22.1.

## Set up on the phone

1. Open VoxFlow and allow microphone access.
2. Tap **Open settings**, then enable **VoxFlow Voice Keyboard**.
3. Return to VoxFlow and tap **Choose keyboard**.
4. Select VoxFlow, tap the test box, then tap **Start dictating** on the keyboard.

Android shows a standard warning when enabling any third-party keyboard. VoxFlow declares only microphone access and includes no app-level internet permission.

## Updating a test install

Debug APKs produced on different GitHub runners may use different signing keys. If Android says an update is incompatible, uninstall the previous VoxFlow test build, then install the new APK. A production release should use one persistent release signing key stored in GitHub Secrets; never commit that key.

## Project structure

- `app/src/main/java/.../VoxFlowInputMethodService.java` — voice keyboard and engine selection
- `app/src/main/java/.../WhisperEngine.java` — microphone capture, voice activity detection, and local inference queue
- `app/src/main/cpp/whisper_jni.cpp` — native bridge to pinned `whisper.cpp`
- `app/src/main/java/.../TextCleaner.java` — local text cleanup
- `app/src/main/java/.../MainActivity.java` — guided setup, test editor, and preferences
- `.github/workflows/build-apk.yml` — reproducible APK build

## Next quality upgrades

The highest-impact next step is testing on the exact target phone and then choosing between the current multilingual `base` model and a larger quantized model. A larger model can improve recognition but substantially increases APK size, RAM use, heat, and response time. A small on-device rewrite model would be a separate later upgrade for deeper semantic corrections.

## Open-source components

- [`whisper.cpp`](https://github.com/ggml-org/whisper.cpp), pinned to v1.9.4 at build time (MIT license).
- Multilingual `ggml-base.bin` from the official [`ggerganov/whisper.cpp`](https://huggingface.co/ggerganov/whisper.cpp) model repository, verified against the SHA-1 published by the project.
