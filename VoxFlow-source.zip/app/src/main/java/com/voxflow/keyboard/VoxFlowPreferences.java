package com.voxflow.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class VoxFlowPreferences {
    static final String[] LANGUAGE_LABELS = {
            "Device language", "English (India)", "English (US)", "English (UK)",
            "Hindi", "Bengali", "Tamil", "Telugu", "Marathi", "Spanish", "French", "German"
    };

    static final String[] LANGUAGE_TAGS = {
            "", "en-IN", "en-US", "en-GB", "hi-IN", "bn-IN", "ta-IN", "te-IN", "mr-IN",
            "es-ES", "fr-FR", "de-DE"
    };

    private static final String FILE = "voxflow_preferences";
    private static final String KEY_LANGUAGE = "language_index";
    private static final String KEY_CLEAN = "clean_enabled";
    private static final String KEY_OFFLINE = "offline_preferred";
    private static final String KEY_VOCABULARY = "vocabulary";

    private VoxFlowPreferences() {}

    static SharedPreferences store(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static int languageIndex(Context context) {
        int index = store(context).getInt(KEY_LANGUAGE, 0);
        return Math.max(0, Math.min(index, LANGUAGE_TAGS.length - 1));
    }

    static String languageTag(Context context) {
        String selected = LANGUAGE_TAGS[languageIndex(context)];
        return selected.isEmpty() ? Locale.getDefault().toLanguageTag() : selected;
    }

    static String whisperLanguage(Context context) {
        String tag = languageTag(context);
        int separator = tag.indexOf('-');
        return separator > 0 ? tag.substring(0, separator) : tag;
    }

    static boolean cleanEnabled(Context context) {
        return store(context).getBoolean(KEY_CLEAN, true);
    }

    static boolean offlinePreferred(Context context) {
        return store(context).getBoolean(KEY_OFFLINE, true);
    }

    static String vocabulary(Context context) {
        return store(context).getString(KEY_VOCABULARY, "");
    }

    static void save(Context context, int languageIndex, boolean clean, boolean offline, String vocabulary) {
        store(context).edit()
                .putInt(KEY_LANGUAGE, languageIndex)
                .putBoolean(KEY_CLEAN, clean)
                .putBoolean(KEY_OFFLINE, offline)
                .putString(KEY_VOCABULARY, vocabulary == null ? "" : vocabulary.trim())
                .apply();
    }
}

