package com.voxflow.keyboard;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Process;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class WhisperEngine {
    interface Listener {
        void onWhisperReady();
        void onWhisperVoiceState(boolean speaking);
        void onWhisperTranscribing();
        void onWhisperResult(String text);
        void onWhisperError(String message);
    }

    private static final String MODEL_ASSET = "models/ggml-base.bin";
    private static final int SAMPLE_RATE = 16_000;
    private static final int BUFFER_SAMPLES = 1_024;
    private static final int PRE_ROLL_SAMPLES = SAMPLE_RATE / 4;
    private static final int MIN_UTTERANCE_SAMPLES = SAMPLE_RATE / 3;
    private static final int MAX_UTTERANCE_SAMPLES = SAMPLE_RATE * 22;
    private static final long SILENCE_TO_COMMIT_MS = 720L;
    private static final float MIN_VOICE_RMS = 0.012f;

    private final Context context;
    private final Listener listener;
    private final ExecutorService modelExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService inferenceExecutor = Executors.newSingleThreadExecutor();

    private volatile boolean requested;
    private volatile boolean closed;
    private volatile long contextPointer;
    private Thread recorderThread;
    private AudioRecord audioRecord;
    private String language = "en";
    private String prompt = "";

    WhisperEngine(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    synchronized void start(String language, String prompt) {
        if (closed) {
            listener.onWhisperError("The offline engine has already been closed.");
            return;
        }
        if (requested) return;
        requested = true;
        this.language = language == null || language.isEmpty() ? "auto" : language;
        this.prompt = prompt == null ? "" : prompt;

        if (contextPointer != 0L) {
            startRecorder();
            listener.onWhisperReady();
            return;
        }

        modelExecutor.submit(() -> {
            try {
                long loaded = WhisperNative.initContextFromAsset(context.getAssets(), MODEL_ASSET);
                if (loaded == 0L) throw new IllegalStateException("The bundled Whisper model could not be loaded.");
                if (closed) {
                    WhisperNative.freeContext(loaded);
                    return;
                }
                contextPointer = loaded;
                if (requested) {
                    startRecorder();
                    listener.onWhisperReady();
                }
            } catch (Throwable error) {
                requested = false;
                listener.onWhisperError("Offline Whisper failed to load: " + safeMessage(error));
            }
        });
    }

    synchronized void stop() {
        requested = false;
        AudioRecord current = audioRecord;
        if (current != null) {
            try {
                current.stop();
            } catch (IllegalStateException ignored) {}
        }
    }

    synchronized void close() {
        closed = true;
        stop();
        modelExecutor.execute(() -> {
            inferenceExecutor.execute(() -> {
                long pointer = contextPointer;
                contextPointer = 0L;
                if (pointer != 0L) WhisperNative.freeContext(pointer);
            });
            inferenceExecutor.shutdown();
        });
        modelExecutor.shutdown();
    }

    private synchronized void startRecorder() {
        if (!requested || recorderThread != null && recorderThread.isAlive()) return;
        recorderThread = new Thread(this::recordLoop, "VoxFlow-Recorder");
        recorderThread.start();
    }

    private void recordLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        int minimum = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
        );
        int bufferBytes = Math.max(minimum, BUFFER_SAMPLES * 4);
        AudioRecord recorder = null;
        try {
            recorder = new AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferBytes
            );
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Microphone could not be initialized.");
            }
            audioRecord = recorder;
            recorder.startRecording();

            short[] buffer = new short[BUFFER_SAMPLES];
            ShortRingBuffer preRoll = new ShortRingBuffer(PRE_ROLL_SAMPLES);
            ShortAccumulator utterance = new ShortAccumulator(SAMPLE_RATE * 4);
            boolean speaking = false;
            long lastVoiceAt = 0L;
            float noiseFloor = 0.004f;

            while (requested) {
                int count = recorder.read(buffer, 0, buffer.length, AudioRecord.READ_BLOCKING);
                if (count <= 0) continue;

                float rms = rms(buffer, count);
                if (!speaking) noiseFloor = noiseFloor * 0.96f + Math.min(rms, 0.02f) * 0.04f;
                float threshold = Math.max(MIN_VOICE_RMS, noiseFloor * 2.7f);
                boolean voiceNow = rms >= threshold;
                long now = System.currentTimeMillis();

                if (voiceNow) {
                    lastVoiceAt = now;
                    if (!speaking) {
                        speaking = true;
                        utterance.add(preRoll.snapshot(), preRoll.size());
                        listener.onWhisperVoiceState(true);
                    }
                }

                if (speaking) utterance.add(buffer, count);
                else preRoll.add(buffer, count);

                boolean longEnough = utterance.size() >= MIN_UTTERANCE_SAMPLES;
                boolean silenceReached = speaking && longEnough && now - lastVoiceAt >= SILENCE_TO_COMMIT_MS;
                boolean maxReached = utterance.size() >= MAX_UTTERANCE_SAMPLES;
                if (silenceReached || maxReached) {
                    submitUtterance(utterance.toFloatArray());
                    utterance.clear();
                    preRoll.clear();
                    speaking = false;
                    listener.onWhisperVoiceState(false);
                }
            }

            if (!closed && utterance.size() >= MIN_UTTERANCE_SAMPLES) {
                submitUtterance(utterance.toFloatArray());
            }
        } catch (Throwable error) {
            if (requested) listener.onWhisperError("Offline recording stopped: " + safeMessage(error));
        } finally {
            if (recorder != null) {
                try {
                    recorder.stop();
                } catch (IllegalStateException ignored) {}
                recorder.release();
            }
            audioRecord = null;
        }
    }

    private void submitUtterance(float[] audio) {
        final String selectedLanguage = language;
        final String vocabularyPrompt = prompt;
        inferenceExecutor.submit(() -> {
            listener.onWhisperTranscribing();
            try {
                long pointer = contextPointer;
                if (pointer == 0L) throw new IllegalStateException("Whisper model is not loaded.");
                String result = WhisperNative.transcribe(
                        pointer,
                        preferredThreadCount(),
                        audio,
                        selectedLanguage,
                        vocabularyPrompt
                );
                listener.onWhisperResult(result == null ? "" : result.trim());
            } catch (Throwable error) {
                listener.onWhisperError("Offline transcription failed: " + safeMessage(error));
            }
        });
    }

    private int preferredThreadCount() {
        int processors = Runtime.getRuntime().availableProcessors();
        return Math.max(2, Math.min(6, processors - 2));
    }

    private static float rms(short[] values, int count) {
        double sum = 0d;
        for (int i = 0; i < count; i++) {
            float normalized = values[i] / 32768f;
            sum += normalized * normalized;
        }
        return (float) Math.sqrt(sum / Math.max(1, count));
    }

    private static String safeMessage(Throwable error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? error.getClass().getSimpleName() : message;
    }

    private static final class ShortAccumulator {
        private short[] values;
        private int size;

        ShortAccumulator(int initialCapacity) {
            values = new short[initialCapacity];
        }

        void add(short[] source, int count) {
            if (count <= 0) return;
            ensureCapacity(size + count);
            System.arraycopy(source, 0, values, size, count);
            size += count;
        }

        int size() {
            return size;
        }

        void clear() {
            size = 0;
        }

        float[] toFloatArray() {
            float[] output = new float[size];
            for (int i = 0; i < size; i++) output[i] = values[i] / 32768f;
            return output;
        }

        private void ensureCapacity(int required) {
            if (required <= values.length) return;
            int next = Math.max(required, values.length * 2);
            short[] expanded = new short[next];
            System.arraycopy(values, 0, expanded, 0, size);
            values = expanded;
        }
    }

    private static final class ShortRingBuffer {
        private final short[] values;
        private int cursor;
        private int size;

        ShortRingBuffer(int capacity) {
            values = new short[capacity];
        }

        void add(short[] source, int count) {
            for (int i = 0; i < count; i++) {
                values[cursor] = source[i];
                cursor = (cursor + 1) % values.length;
                if (size < values.length) size++;
            }
        }

        short[] snapshot() {
            short[] output = new short[size];
            int start = (cursor - size + values.length) % values.length;
            for (int i = 0; i < size; i++) output[i] = values[(start + i) % values.length];
            return output;
        }

        int size() {
            return size;
        }

        void clear() {
            cursor = 0;
            size = 0;
        }
    }
}

