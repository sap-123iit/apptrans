package com.voxflow.keyboard;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int MICROPHONE_PERMISSION_REQUEST = 41;

    private TextView permissionStatus;
    private TextView enableStatus;
    private TextView switchStatus;
    private Button permissionButton;
    private Button enableButton;
    private Button switchButton;
    private Spinner languageSpinner;
    private Switch cleanSwitch;
    private Switch offlineSwitch;
    private EditText vocabularyEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applySystemBarInsets();
        bindViews();
        loadPreferences();
        bindActions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshSetupState();
    }

    private void applySystemBarInsets() {
        View content = findViewById(R.id.content);
        int left = content.getPaddingLeft();
        int top = content.getPaddingTop();
        int right = content.getPaddingRight();
        int bottom = content.getPaddingBottom();
        content.setOnApplyWindowInsetsListener((view, insets) -> {
            int status = insets.getSystemWindowInsetTop();
            int navigation = insets.getSystemWindowInsetBottom();
            view.setPadding(left, top + status, right, bottom + navigation);
            return insets;
        });
        content.requestApplyInsets();
    }

    private void bindViews() {
        permissionStatus = findViewById(R.id.permissionStatus);
        enableStatus = findViewById(R.id.enableStatus);
        switchStatus = findViewById(R.id.switchStatus);
        permissionButton = findViewById(R.id.permissionButton);
        enableButton = findViewById(R.id.enableButton);
        switchButton = findViewById(R.id.switchButton);
        languageSpinner = findViewById(R.id.languageSpinner);
        cleanSwitch = findViewById(R.id.cleanSwitch);
        offlineSwitch = findViewById(R.id.offlineSwitch);
        vocabularyEditor = findViewById(R.id.vocabularyEditor);
    }

    private void loadPreferences() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, VoxFlowPreferences.LANGUAGE_LABELS
        );
        languageSpinner.setAdapter(adapter);
        languageSpinner.setSelection(VoxFlowPreferences.languageIndex(this));
        cleanSwitch.setChecked(VoxFlowPreferences.cleanEnabled(this));
        offlineSwitch.setChecked(VoxFlowPreferences.offlinePreferred(this));
        vocabularyEditor.setText(VoxFlowPreferences.vocabulary(this));
    }

    private void bindActions() {
        permissionButton.setOnClickListener(view -> requestPermissions(
                new String[]{Manifest.permission.RECORD_AUDIO}, MICROPHONE_PERMISSION_REQUEST
        ));

        enableButton.setOnClickListener(view -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));

        switchButton.setOnClickListener(view -> {
            InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            manager.showInputMethodPicker();
        });

        findViewById(R.id.saveButton).setOnClickListener(view -> {
            VoxFlowPreferences.save(
                    this,
                    languageSpinner.getSelectedItemPosition(),
                    cleanSwitch.isChecked(),
                    offlineSwitch.isChecked(),
                    vocabularyEditor.getText().toString()
            );
            Toast.makeText(this, R.string.preferences_saved, Toast.LENGTH_SHORT).show();
        });
    }

    private void refreshSetupState() {
        boolean hasMicrophone = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean enabled = isInputMethodEnabled();
        boolean selected = isInputMethodSelected();

        renderStep(permissionStatus, permissionButton, "1", "Allow microphone access", hasMicrophone);
        renderStep(enableStatus, enableButton, "2", "Enable VoxFlow", enabled);
        renderStep(switchStatus, switchButton, "3", "Switch to VoxFlow", selected);
    }

    private void renderStep(TextView status, Button button, String number, String label, boolean complete) {
        status.setText((complete ? "✓" : number) + "  ·  " + label);
        status.setTextColor(getColor(complete ? R.color.accent_dark : R.color.ink));
        button.setText(complete ? R.string.ready : button == permissionButton ? R.string.allow :
                button == enableButton ? R.string.open_settings : R.string.choose_keyboard);
        button.setEnabled(!complete || button == switchButton);
        button.setAlpha(button.isEnabled() ? 1f : 0.55f);
    }

    private boolean isInputMethodEnabled() {
        String enabledMethods = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_INPUT_METHODS);
        return enabledMethods != null && enabledMethods.contains(new ComponentName(this, VoxFlowInputMethodService.class).flattenToShortString());
    }

    private boolean isInputMethodSelected() {
        String current = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return current != null && current.equals(new ComponentName(this, VoxFlowInputMethodService.class).flattenToShortString());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MICROPHONE_PERMISSION_REQUEST) refreshSetupState();
    }
}

