package com.voxflow.keyboard;

import android.content.res.AssetManager;

final class WhisperNative {
    static {
        System.loadLibrary("voxwhisper");
    }

    private WhisperNative() {}

    static native long initContextFromAsset(AssetManager assets, String assetPath);
    static native void freeContext(long contextPointer);
    static native String transcribe(
            long contextPointer,
            int threadCount,
            float[] audio,
            String language,
            String prompt
    );
}

